﻿namespace AP_CA
{
    partial class addstudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblemaile = new System.Windows.Forms.Label();
            this.lblmoe = new System.Windows.Forms.Label();
            this.lblsurnamee = new System.Windows.Forms.Label();
            this.lblnamee = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txtcontact = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtpin = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtsurname = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblemaile);
            this.groupBox1.Controls.Add(this.lblmoe);
            this.groupBox1.Controls.Add(this.lblsurnamee);
            this.groupBox1.Controls.Add(this.lblnamee);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.txtemail);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtcontact);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtpin);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtaddress);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtsurname);
            this.groupBox1.Controls.Add(this.txtname);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(49, 162);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(417, 253);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Personal Detail";
            // 
            // lblemaile
            // 
            this.lblemaile.AutoSize = true;
            this.lblemaile.ForeColor = System.Drawing.Color.Red;
            this.lblemaile.Location = new System.Drawing.Point(290, 153);
            this.lblemaile.Name = "lblemaile";
            this.lblemaile.Size = new System.Drawing.Size(12, 15);
            this.lblemaile.TabIndex = 19;
            this.lblemaile.Text = "*";
            this.lblemaile.Visible = false;
            // 
            // lblmoe
            // 
            this.lblmoe.AutoSize = true;
            this.lblmoe.ForeColor = System.Drawing.Color.Red;
            this.lblmoe.Location = new System.Drawing.Point(396, 71);
            this.lblmoe.Name = "lblmoe";
            this.lblmoe.Size = new System.Drawing.Size(12, 15);
            this.lblmoe.TabIndex = 18;
            this.lblmoe.Text = "*";
            this.lblmoe.Visible = false;
            // 
            // lblsurnamee
            // 
            this.lblsurnamee.AutoSize = true;
            this.lblsurnamee.ForeColor = System.Drawing.Color.Red;
            this.lblsurnamee.Location = new System.Drawing.Point(195, 73);
            this.lblsurnamee.Name = "lblsurnamee";
            this.lblsurnamee.Size = new System.Drawing.Size(12, 15);
            this.lblsurnamee.TabIndex = 17;
            this.lblsurnamee.Text = "*";
            this.lblsurnamee.Visible = false;
            // 
            // lblnamee
            // 
            this.lblnamee.AutoSize = true;
            this.lblnamee.ForeColor = System.Drawing.Color.Red;
            this.lblnamee.Location = new System.Drawing.Point(195, 35);
            this.lblnamee.Name = "lblnamee";
            this.lblnamee.Size = new System.Drawing.Size(12, 15);
            this.lblnamee.TabIndex = 16;
            this.lblnamee.Text = "*";
            this.lblnamee.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(27, 149);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 15);
            this.label14.TabIndex = 15;
            this.label14.Text = "E - mail :";
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(88, 151);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(196, 21);
            this.txtemail.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(323, 159);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(67, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "Next ..";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(211, 71);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 15);
            this.label7.TabIndex = 12;
            this.label7.Text = "Contact No :";
            // 
            // txtcontact
            // 
            this.txtcontact.Location = new System.Drawing.Point(290, 69);
            this.txtcontact.Name = "txtcontact";
            this.txtcontact.Size = new System.Drawing.Size(100, 21);
            this.txtcontact.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(226, 38);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 15);
            this.label6.TabIndex = 10;
            this.label6.Text = "Pincode :";
            // 
            // txtpin
            // 
            this.txtpin.Location = new System.Drawing.Point(290, 35);
            this.txtpin.Name = "txtpin";
            this.txtpin.Size = new System.Drawing.Size(100, 21);
            this.txtpin.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(29, 119);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "Address :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(22, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "Surname :";
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(88, 110);
            this.txtaddress.Multiline = true;
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(196, 34);
            this.txtaddress.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(39, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "Name :";
            // 
            // txtsurname
            // 
            this.txtsurname.Location = new System.Drawing.Point(89, 71);
            this.txtsurname.Name = "txtsurname";
            this.txtsurname.Size = new System.Drawing.Size(100, 21);
            this.txtsurname.TabIndex = 1;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(89, 35);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(100, 21);
            this.txtname.TabIndex = 0;
            // 
            // addstudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 681);
            this.Controls.Add(this.groupBox1);
            this.Name = "addstudent";
            this.Text = "addstudent";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblemaile;
        private System.Windows.Forms.Label lblmoe;
        private System.Windows.Forms.Label lblsurnamee;
        private System.Windows.Forms.Label lblnamee;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtcontact;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtpin;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtsurname;
        private System.Windows.Forms.TextBox txtname;
    }
}